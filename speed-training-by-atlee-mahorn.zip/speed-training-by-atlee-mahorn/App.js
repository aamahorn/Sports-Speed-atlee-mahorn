import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar
} from 'react-native';

export default function App() {
  const [selectedSport, setSelectedSport] = useState('Football');
  const [activeTab, setActiveTab] = useState('sports');

  const sportsData = {
    'Football': { icon: '🏈', color: '#1e40af', focus: 'Acceleration & Power' },
    'Soccer': { icon: '⚽', color: '#1e40af', focus: 'Speed Endurance' },
    'Basketball': { icon: '🏀', color: '#1e40af', focus: 'Court Speed' },
    'Baseball': { icon: '⚾', color: '#1e40af', focus: 'Base Running' },
    'Lacrosse': { icon: '🥍', color: '#1e40af', focus: 'Field Transition' },
    'Track & Field': { icon: '🏃‍♂️', color: '#1e40af', focus: 'Pure Speed' }
  };

  const renderSportsLanding = () => (
    <View>
      <View style={styles.sportsShowcase}>
        <Text style={styles.sectionTitle}>🏆 Olympic Training for 6 Sports</Text>
        <Text style={styles.description}>
          Olympic methodology adapted for high school athletic programs
        </Text>
        
        <View style={styles.sportsGrid}>
          {Object.entries(sportsData).map(([sport, data]) => (
            <TouchableOpacity 
              key={sport}
              style={[
                styles.sportCard,
                { 
                  backgroundColor: selectedSport === sport ? '#1e40af' : 'white',
                  borderColor: selectedSport === sport ? '#1e40af' : '#e2e8f0'
                }
              ]}
              onPress={() => setSelectedSport(sport)}
            >
              <Text style={styles.sportIcon}>{data.icon}</Text>
              <Text style={[
                styles.sportName,
                { color: selectedSport === sport ? 'white' : '#1e40af' }
              ]}>
                {sport}
              </Text>
              <Text style={[
                styles.sportFocus,
                { color: selectedSport === sport ? 'rgba(255,255,255,0.9)' : '#6b7280' }
              ]}>
                {data.focus}
              </Text>
              <View style={[
                styles.sportBadge,
                { backgroundColor: selectedSport === sport ? 'white' : '#1e40af' }
              ]}>
                <Text style={[
                  styles.badgeText,
                  { color: selectedSport === sport ? '#1e40af' : 'white' }
                ]}>
                  {selectedSport === sport ? 'Selected' : 'Select Sport'}
                </Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Training Builder for {selectedSport}</Text>
        <Text style={styles.description}>
          Sport-specific speed training adapted from Olympic methodology
        </Text>
        <View style={styles.selectedSportInfo}>
          <Text style={styles.infoText}>Focus: {sportsData[selectedSport].focus}</Text>
          <Text style={styles.infoText}>16-week periodized training system</Text>
          <Text style={styles.infoText}>Champion optimization methods included</Text>
        </View>
      </View>
    </View>
  );

  const renderTrainingBuilder = () => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Training Builder</Text>
      <Text style={styles.description}>
        Build custom training sessions for {selectedSport}
      </Text>
      <TouchableOpacity style={styles.builderButton}>
        <Text style={styles.buttonText}>Generate Speed Session</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.builderButton}>
        <Text style={styles.buttonText}>Generate Strength Session</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.builderButton}>
        <Text style={styles.buttonText}>Generate Endurance Session</Text>
      </TouchableOpacity>
    </View>
  );

  const renderReports = () => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Reports & Charts</Text>
      <Text style={styles.description}>
        Performance tracking and analytics for {selectedSport}
      </Text>
      <TouchableOpacity style={styles.reportButton}>
        <Text style={styles.buttonText}>Performance Progress</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.reportButton}>
        <Text style={styles.buttonText}>16-Week Overview</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#1e40af" />
      
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <Text style={styles.title}>🏃‍♂️ Speed Training by Atlee Mahorn</Text>
          <Text style={styles.subtitle}>3-Time Olympic Participant • Multi-Sport Training System</Text>
        </View>

        <View style={styles.tabNavigation}>
          <TouchableOpacity 
            style={[styles.tabButton, activeTab === 'sports' && styles.activeTab]}
            onPress={() => setActiveTab('sports')}
          >
            <Text style={[styles.tabText, activeTab === 'sports' && styles.activeTabText]}>
              Sports
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.tabButton, activeTab === 'training' && styles.activeTab]}
            onPress={() => setActiveTab('training')}
          >
            <Text style={[styles.tabText, activeTab === 'training' && styles.activeTabText]}>
              Training Builder
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.tabButton, activeTab === 'reports' && styles.activeTab]}
            onPress={() => setActiveTab('reports')}
          >
            <Text style={[styles.tabText, activeTab === 'reports' && styles.activeTabText]}>
              Reports
            </Text>
          </TouchableOpacity>
        </View>

        {activeTab === 'sports' && renderSportsLanding()}
        {activeTab === 'training' && renderTrainingBuilder()}
        {activeTab === 'reports' && renderReports()}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  scrollContainer: {
    padding: 20,
  },
  header: {
    backgroundColor: '#1e40af',
    padding: 30,
    borderRadius: 15,
    marginBottom: 25,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.9)',
    textAlign: 'center',
  },
  tabNavigation: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 12,
    marginBottom: 20,
    padding: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  activeTab: {
    backgroundColor: '#1e40af',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6b7280',
  },
  activeTabText: {
    color: 'white',
  },
  sportsShowcase: {
    marginBottom: 25,
  },
  sportsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 15,
  },
  sportCard: {
    width: '48%',
    padding: 20,
    borderRadius: 12,
    marginBottom: 15,
    alignItems: 'center',
    borderWidth: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sportIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  sportName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
    textAlign: 'center',
  },
  sportFocus: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 8,
  },
  sportBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: 'bold',
  },
  section: {
    backgroundColor: 'white',
    padding: 25,
    borderRadius: 15,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 15,
  },
  description: {
    fontSize: 16,
    color: '#4b5563',
    lineHeight: 24,
    marginBottom: 20,
  },
  selectedSportInfo: {
    backgroundColor: '#f8fafc',
    padding: 15,
    borderRadius: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#1e40af',
  },
  infoText: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 8,
  },
  builderButton: {
    backgroundColor: '#1e40af',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    alignItems: 'center',
  },
  reportButton: {
    backgroundColor: '#3b82f6',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});import { Text, SafeAreaView, StyleSheet } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Change code in the editor and watch it change on your phone! Save to get a shareable url.
      </Text>
      <Card>
        <AssetExample />
      </Card>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
